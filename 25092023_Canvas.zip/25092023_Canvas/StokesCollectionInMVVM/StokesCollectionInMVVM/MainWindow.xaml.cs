﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace StokesCollectionInMVVM
{
    public struct DoStroke
    {
        public string ActionFlag { get; set; }
        public System.Windows.Ink.Stroke Stroke { get; set; }
    }
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public Stack<DoStroke> DoStrokes { get; set; }

        public Stack<DoStroke> UndoStrokes { get; set; }

        private bool handle = true;

        MainWindowsViewModel obj = null;
        public MainWindow()
        {
            InitializeComponent();
           obj=new MainWindowsViewModel(this);
            this.DataContext = obj;

            DoStrokes = new Stack<DoStroke>();

            UndoStrokes = new Stack<DoStroke>();

            myCanvas.DefaultDrawingAttributes.FitToCurve = true;

            myCanvas.Strokes.StrokesChanged += Strokes_StrokesChanged;
        }

        public void Strokes_StrokesChanged(object sender, System.Windows.Ink.StrokeCollectionChangedEventArgs e)
        {


            if (handle)
            {
                DoStrokes.Push(new DoStroke
                {
                    ActionFlag = e.Added.Count > 0 ? "ADD" : "REMOVE",
                    Stroke = e.Added.Count > 0 ? e.Added[0] : e.Removed[0]
                });
            }
        }

        public void Undo(object sender, RoutedEventArgs e)
        {
            handle = false;
            if (obj.StrokesEllipse.Count > 0)
            {

            }
              if (DoStrokes.Count > 0)
            //if (obj.StrokesEllipse.Count > 0)
            {
                DoStroke @do = DoStrokes.Pop();
                if (@do.ActionFlag.Equals("ADD"))
                {
                    myCanvas.Strokes.Remove(@do.Stroke);
                }
                else
                {
                    myCanvas.Strokes.Add(@do.Stroke);
                }

                UndoStrokes.Push(@do);
            }
            handle = true;
        }

        public void Redo(object sender, RoutedEventArgs e)
        {
            handle = false;
            if (UndoStrokes.Count > 0)
           // if (obj.StrokesEllipse.Count > 0)
            {
                DoStroke @do = UndoStrokes.Pop();
                if (@do.ActionFlag.Equals("ADD"))
                {
                    myCanvas.Strokes.Add(@do.Stroke);
                }
                else
                {
                    myCanvas.Strokes.Remove(@do.Stroke);
                }
            }
            handle = true;
        }

        private void SliderValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (myCanvas != null)
            {
                var drawingAttributes = myCanvas.DefaultDrawingAttributes;
                Double newSize = Math.Round(BrushRadiusSlider.Value, 0);
                drawingAttributes.Width = newSize;
                drawingAttributes.Height = newSize;
            }
        }


        public void cp_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            if (cp.SelectedColor.HasValue)
            {
                Color C = cp.SelectedColor.Value;
                this.strokeAttr.Color = C;
            }
        }

        private void buttonSaveAsClick(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "isf files (*.isf)|*.isf";

            if (saveFileDialog1.ShowDialog() == true)
            {
                FileStream fs = new FileStream(saveFileDialog1.FileName,
                                               FileMode.Create);
                myCanvas.Strokes.Save(fs);
                fs.Close();
            }
        }

        private void buttonLoadClick(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "isf files (*.isf)|*.isf";

            if (openFileDialog1.ShowDialog() == true)
            {
                FileStream fs = new FileStream(openFileDialog1.FileName,
                                               FileMode.Open);
                myCanvas.Strokes = new StrokeCollection(fs);
                fs.Close();
            }
        }

  
    }


}
