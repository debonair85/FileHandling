﻿using StokesCollectionInMVVM.Command;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;

namespace StokesCollectionInMVVM
{
    internal class MainWindowsViewModel : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region Class variables       

        private StrokeCollection _strokesEllipse = null;

        #endregion
        MainWindow mainWin = null;

        public MainWindowsViewModel(MainWindow mainWin)
        {
            this.mainWin = mainWin;
            if (EllipseDrawing != null)
            {
                using (var memoryStream = new MemoryStream(EllipseDrawing))
                {
                    _strokesEllipse = new StrokeCollection(memoryStream);

                }
            }
            else
            {
                _strokesEllipse = new StrokeCollection();
            }

            (_strokesEllipse as INotifyCollectionChanged).CollectionChanged += new NotifyCollectionChangedEventHandler(MainWindowsViewModel_CollectionChanged);

            DoCommand = new RelayCommand(DoStuff);
            this.mainWin = mainWin;
        }

        public ICommand DoCommand
        {
         
            get; set;
        }

        void MainWindowsViewModel_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            StrokesEllipse = ((StrokeCollection)sender);
            using (var memoryStream = new MemoryStream())
            {
                StrokesEllipse.Save(memoryStream);
                //convert memory stream to  array
                EllipseDrawing = memoryStream.ToArray();
                //save the above array to say - database
            }
            if(e.Action == NotifyCollectionChangedAction.Add)
            {
                DoStroke obj=new DoStroke(sender, "ADD");
            }
            //DoStroke.
            //mainWin.Strokes_StrokesChanged(sender, e);
        }

        #region Properties 

        public Stack<DoStroke> DoStrokes { get; set; }
        public Stack<DoStroke> UndoStrokes { get; set; }

        public StrokeCollection StrokesEllipse
        {
            get
            {
                return _strokesEllipse;
            }
            set
            {
                _strokesEllipse = value;            
                RaisePropertyChanged("StrokesEllipse");
            }
        }

        

        public byte[] EllipseDrawing
        {
            get;
            set;
        }

        private double _strokeWidth;
        public double StrokeWidth 
        { 
            get
            {
              
                return _strokeWidth;
            }
            set
            {
                _strokeWidth=value;
                RaisePropertyChanged("StrokeWidth");
            }
        }

        private InkCanvasEditingMode _canvasEditingMode;
        public InkCanvasEditingMode CanvasEditingMode
        {
            get
            {
                return _canvasEditingMode;
            }
            set
            {
                _canvasEditingMode = value;
                RaisePropertyChanged("CanvasEditingMode");
            }
        }
        private void DoStuff(object sender)
        {
  

            string radiobutton = (sender).ToString();
            if (radiobutton == "Draw")
            {
                CanvasEditingMode = InkCanvasEditingMode.Ink;
            }
            else if (radiobutton == "Erase")
            {
                CanvasEditingMode = InkCanvasEditingMode.EraseByStroke;
            }
            else if (radiobutton == "Select")
            {
                CanvasEditingMode = InkCanvasEditingMode.Select;
            }
        }

        #endregion 

       

    }

  
}
